This program was written with PYTHON 3 in mind. It is recommended that this program be run in IDLE, which comes with the Windows installation package for Python 3. To run from command line:
	py problem1.py


To run the Hilbert routine, simply type py problem1.py into the terminal. There is no need to manipulate or change any of the code. It should work out of the box.

